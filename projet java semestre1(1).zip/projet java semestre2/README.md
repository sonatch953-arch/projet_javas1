# 🥚 Projet Java : Tamagotchis

Petit jeu console en Java : maintenir en vie une colonie de **tamagotchis** (animaux virtuels) en les nourrissant au bon moment.

> Projet issu du TD2 de Java (Exercice 1 : Tamagotchis).

---

## 📌 Présentation

Le mot *Tamagotchi* vient de **tamago** (œuf) et **watch** (montre). C'est un animal de compagnie virtuel qui :

- **vit** : il vieillit et perd de l'énergie à chaque cycle ;
- **doit être nourri** pour ne pas mourir de faim.

Le joueur crée `n` tamagotchis, puis, à chaque cycle, choisit celui qu'il veut nourrir.

### Conditions de fin

| Résultat | Condition |
|----------|-----------|
| 🏆 **GAGNÉ** | Tous les tamagotchis ont atteint leur âge limite |
| 💀 **PERDU** | Un tamagotchi est mort de faim |

---

## 📁 Structure du projet

```
projet-tamagotchi/
├── Tamagotchi.java          # La classe qui représente un animal
├── SimulTamagotchis.java    # Le programme principal (méthode main)
└── README.md
```

---

## 🧬 La classe `Tamagotchi`

### Attributs (privés)

| Attribut | Type | Rôle | Valeur initiale |
|----------|------|------|-----------------|
| `nom` | `String` | Le prénom de l'animal | Donné par l'utilisateur |
| `age` | `int` | Nombre de cycles vécus | `0` |
| `dureeDeVie` | `int` | Âge à atteindre pour « gagner » | Aléatoire entre **9 et 14** |
| `maxEnergie` | `int` | Énergie maximale (taille du ventre) | Aléatoire entre **5 et 9** |
| `energie` | `int` | Énergie actuelle (jauge de faim) | Aléatoire entre **3 et `maxEnergie`** |

### Méthodes

| Méthode | Description |
|---------|-------------|
| `Tamagotchi(String nom)` | Constructeur : initialise les attributs (avec du hasard). |
| `void parler()` | Affiche le nom et l'état : *tout va bien !* si `energie > 5`, sinon *je suis affamé !*. |
| `void manger()` | Ajoute 1 à 3 d'énergie (au hasard), **sans dépasser `maxEnergie`**. Si l'énergie est déjà au maximum, l'animal n'a pas faim et le montre. |
| `boolean ageLimite()` | Retourne `true` si l'animal a atteint sa durée de vie. |
| `boolean vivre()` | Fait vivre l'animal un cycle (voir ci-dessous). |
| `String getNom()` | Retourne le nom de l'animal. |

### Fonctionnement de `vivre()`

Les trois cas sont testés **dans cet ordre** :

1. **`age == dureeDeVie`** : l'animal ne fait rien, retourne `true`.
2. **`energie <= 0`** : il affiche « je meurs... Arrrggh ! » et retourne `false`.
3. **Sinon** : `age` augmente de 1, `energie` diminue de 1. Si l'âge limite est atteint, il affiche un message de victoire ; sinon il parle. Retourne `true`.

---

## 🎮 Le programme `SimulTamagotchis`

Déroulement :

1. L'utilisateur indique le nombre de tamagotchis, puis leurs noms.
2. Boucle de jeu, à chaque cycle :
   - affichage de l'en-tête du cycle ;
   - appel de `vivre()` sur **tous** les tamagotchis : si l'un retourne `false`, c'est **PERDU** ;
   - si tous ont atteint leur âge limite, c'est **GAGNÉ** ;
   - sinon, affichage de la liste des tamagotchis encore en jeu et choix de celui à nourrir (`manger()`).

---

## ▶️ Compilation et exécution

**Prérequis :** un JDK installé (Java 8 ou supérieur).

```bash
# Compilation
javac Tamagotchi.java SimulTamagotchis.java

# Exécution
java SimulTamagotchis
```

> Si les accents s'affichent mal sous Windows : `javac -encoding UTF-8 Tamagotchi.java SimulTamagotchis.java`

---

## 🖥️ Exemple d'exécution

```
Combien de tamagotchis voulez-vous créer ? 3
Quel nom pour le nouveau tamagotchi : Pierre
Quel nom pour le nouveau tamagotchi : Paul
Quel nom pour le nouveau tamagotchi : Jacques
-------Cycle no 1 -------
Pierre : je suis affamé !
Paul : tout va bien !
Jacques : je suis affamé !
(0) Pierre (1) Paul (2) Jacques
Nourrir quel tamagotchi ? 1
Paul : je n'ai pas faim !!
-------Cycle no 2 -------
...
-------Cycle no 5 -------
Pierre : je meurs... Arrrggh !
PERDU !!
```

> Les valeurs étant tirées au hasard, chaque partie est différente.

---

## 💡 Notions Java utilisées

- **Classes et objets** (programmation orientée objet)
- **Encapsulation** : attributs privés et accesseur `getNom()`
- **Constructeur** et initialisation aléatoire (`java.util.Random`)
- **Collections** : `ArrayList<Tamagotchi>`
- **Boucles et conditions** (`while`, `for`, `if`)
- **Saisie utilisateur** avec `Scanner`

---

## 👤 Auteur

Projet réalisé dans le cadre du cours de Java, ISEP Diamniadio.
