import java.util.Random;

/**
 * Un Tamagotchi : animal virtuel qui vit (perd de l'énergie)
 * et qui doit être nourri pour survivre.
 */
public class Tamagotchi {

    // Générateur de nombres aléatoires partagé par tous les tamagotchis
    private static final Random ALEA = new Random();

    // Attributs privés (encapsulation)
    private int age;
    private int dureeDeVie;
    private int maxEnergie;
    private int energie;
    private String nom;

    /**
     * Constructeur : initialise le tamagotchi avec des valeurs aléatoires.
     * @param nom le nom du tamagotchi
     */
    public Tamagotchi(String nom) {
        this.nom = nom;
        this.age = 0;
        // dureeDeVie entre 9 et 14 (inclus)
        this.dureeDeVie = 9 + ALEA.nextInt(6);
        // maxEnergie entre 5 et 9 (inclus)
        this.maxEnergie = 5 + ALEA.nextInt(5);
        // energie entre 3 et maxEnergie (inclus)
        this.energie = 3 + ALEA.nextInt(this.maxEnergie - 3 + 1);
    }

    /**
     * Affiche le nom et l'état de forme du tamagotchi.
     * Heureux si energie > 5, affamé sinon.
     */
    public void parler() {
        if (energie > 5) {
            System.out.println(nom + " : tout va bien !");
        } else {
            System.out.println(nom + " : je suis affamé !");
        }
    }

    /**
     * Nourrit le tamagotchi : energie augmente de 1 à 3,
     * sans jamais dépasser maxEnergie.
     */
    public void manger() {
        if (energie >= maxEnergie) {
            // Déjà au maximum : il n'a pas faim
            System.out.println(nom + " : je n'ai pas faim !!");
        } else {
            int gain = 1 + ALEA.nextInt(3); // valeur entre 1 et 3
            energie = Math.min(energie + gain, maxEnergie); // on ne dépasse pas le max
            System.out.println(nom + " : Merci !");
        }
    }

    /**
     * Teste si le tamagotchi a atteint son âge limite.
     * @return true si age a atteint dureeDeVie
     */
    public boolean ageLimite() {
        return age >= dureeDeVie;
    }

    /**
     * Fait vivre le tamagotchi pendant un cycle.
     * @return false si le tamagotchi meurt de faim, true sinon
     */
    public boolean vivre() {
        // Cas (a) : âge limite déjà atteint, on ne fait rien
        if (age == dureeDeVie) {
            return true;
        }
        // Cas (b) : plus d'énergie, le tamagotchi meurt
        if (energie <= 0) {
            System.out.println(nom + " : je meurs... Arrrggh !");
            return false;
        }
        // Cas (c) : il vieillit et dépense de l'énergie
        age++;
        energie--;
        if (ageLimite()) {
            System.out.println(nom + " : c'est gagné pour moi !");
        } else {
            parler();
        }
        return true;
    }

    /** @return le nom du tamagotchi */
    public String getNom() {
        return nom;
    }
}
