import java.util.ArrayList;
import java.util.Scanner;

/**
 * Simulation d'une colonie de tamagotchis.
 * Gagné : tous les tamagotchis ont atteint leur âge limite.
 * Perdu : un tamagotchi est mort de faim.
 */
public class SimulTamagotchis {

    public static void main(String[] args) {
        Scanner clavier = new Scanner(System.in);

        // 1. Création des tamagotchis
        int n = 0;
        while (n < 1) {
            System.out.print("Combien de tamagotchis voulez-vous créer ? ");
            if (clavier.hasNextInt()) {
                n = clavier.nextInt();
            } else {
                clavier.next(); // on ignore la saisie invalide
            }
        }
        clavier.nextLine(); // consomme la fin de ligne

        ArrayList<Tamagotchi> colonie = new ArrayList<Tamagotchi>();
        for (int i = 0; i < n; i++) {
            System.out.print("Quel nom pour le nouveau tamagotchi : ");
            String nom = clavier.nextLine();
            colonie.add(new Tamagotchi(nom));
        }

        // 2. Boucle de jeu
        int cycle = 1;
        boolean perdu = false;
        boolean gagne = false;

        while (!perdu && !gagne) {
            System.out.println("-------Cycle no " + cycle + " -------");

            // a) vivre() est appliquée sur tous les tamagotchis
            for (Tamagotchi t : colonie) {
                if (!t.vivre()) {
                    perdu = true; // un tamagotchi est mort de faim
                    break;
                }
            }

            if (perdu) {
                System.out.println("PERDU !!");
            } else {
                // b) Tous ont-ils atteint leur âge limite ?
                gagne = true;
                for (Tamagotchi t : colonie) {
                    if (!t.ageLimite()) {
                        gagne = false;
                    }
                }

                if (gagne) {
                    System.out.println("GAGNÉ !!");
                } else {
                    // c) Choix du tamagotchi à nourrir (parmi ceux encore en jeu)
                    for (int i = 0; i < colonie.size(); i++) {
                        if (!colonie.get(i).ageLimite()) {
                            System.out.print("(" + i + ") " + colonie.get(i).getNom() + " ");
                        }
                    }
                    System.out.println();

                    int choix = -1;
                    while (choix < 0 || choix >= colonie.size()
                            || colonie.get(choix).ageLimite()) {
                        System.out.print("Nourrir quel tamagotchi ? ");
                        if (clavier.hasNextInt()) {
                            choix = clavier.nextInt();
                        } else {
                            clavier.next(); // saisie invalide ignorée
                            choix = -1;
                        }
                    }
                    colonie.get(choix).manger();
                    cycle++;
                }
            }
        }

        clavier.close();
    }
}
